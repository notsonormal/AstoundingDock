﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LYCJ (c) 2010 - http://www.quickzip.org/components                                                            //
// Release under LGPL license.                                                                                   //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using QuickZip.IO;

namespace System.IO.Tools
{
    public abstract class WorkBase : IWork, IComparable
    {
        public WorkBase(int id)
        {
            ID = id;
            ConstructTime = DateTime.Now;
            StartTime = DateTime.MaxValue;
            WorkStatus = WorkStatusType.wsCreated;
        }


        #region Methods

        protected abstract void DoWork();



        #region ReportWork
        protected bool ReportWork(WorkProgressEventArgs e)
        {
            if (_aborted)
                return false;
            else
                if (WorkProgress != null)
                {
                    WorkProgress(this, e);
                    if (e.Cancel)
                        Abort();
                    return !e.Cancel;
                }
            return true;
        }
        object lockTotal = new object();

        protected bool ReportWorkProgress(int total, int completed, string file)
        {
            lock (lockTotal)
            {
                Total = total; Completed = completed; ProcessingItem = file;
                return ReportWork(new WorkProgressEventArgs(this.ID, total, completed, file));
            }
        }

        protected bool ReportWorkProgress(int total, int completed)
        {
            return ReportWorkProgress(total, completed, "");
        }

        protected bool AddCompletedCount(int itemCompleted)
        {
            return ReportWorkProgress(Total, Completed + itemCompleted);
        }

        protected bool AddCompletedCount(string processingItem)
        {
            return ReportWorkProgress(Total, Completed + 1, processingItem);
        }

        protected bool AddTotalCount(int totalAdded)
        {
            return ReportWorkProgress(Total + totalAdded, Completed);
        }

        protected bool AddTotalCount(string processingItem)
        {
            return ReportWorkProgress(Total + 1, Completed, processingItem);
        }

        protected bool AddTotalCount()
        {
            return AddTotalCount(1);
        }

        protected bool ReportWorkStart()
        {
            if (WorkStatus != WorkStatusType.wsAborted)
                WorkStatus = WorkStatusType.wsRunning;
            WorkStartEventArgs e = new WorkStartEventArgs(ID);
            if (WorkStart != null)
            {
                WorkStart(this, e);
                return !e.Cancel;
            }
            return true;
        }

        protected void ReportPaused()
        {
            if (WorkPaused != null)
                WorkPaused(this, WorkPausedEventArgs.PausedArgs(ID));
        }

        protected void ReportWorkCompleted()
        {
            if (WorkFinished != null)
                WorkFinished(this, WorkFinishedEventArgs.SuccessArgs(ID));

            if (_finishAction != null)
                _finishAction(this);

        }

        //protected void ReportWorkFailed(string message)
        //{
        //    if (!Aborted)
        //    {
        //        if (WorkFinished != null)
        //            WorkFinished(this, WorkFinishedEventArgs.FailedArgs(ID, message));

        //        WorkResult = WorkResultType.wrSuccess;
        //        if (_finishAction != null)
        //            _finishAction(WorkResult);
        //    }
        //}

        //protected void ReportWorkAborted()
        //{
        //    if (WorkFinished != null)
        //        WorkFinished(this, WorkFinishedEventArgs.AbortArgs(ID));

        //    WorkResult = WorkResultType.wrAborted;
        //    if (_finishAction != null)
        //        _finishAction(WorkResult);
        //}



        #endregion

        #region Pause/Resume
        protected void CheckPause()
        {
            pauseTrigger.WaitOne();
        }

        public bool Paused
        {
            get { return _paused; }
            set { if (value) Pause(); else Resume(); }
        }

        public void Pause()
        {
            pauseTrigger.Reset();
            _paused = true;
            ReportPaused();
        }

        public void Resume()
        {
            pauseTrigger.Set();
            _paused = false;
        }

        public void Abort()
        {
            _aborted = true;

            if (Paused)
                Resume();
        }
        #endregion

        #region OverwriteTools

        protected bool AskOverwriteDialog(string srcName, long srcSize, DateTime srcTime, string srcCRC,
            string destName, long destSize, DateTime destTime, string destCRC)
        {
            bool overwrite = false;

            string compSize = "";
            string compTime = "";
            string compCRC = "";
            if (srcSize == destSize) compSize = "(Same)"; else compSize = "(Different)";
            if (srcTime == destTime) compTime = "(Same)"; else compTime = "(Different)";
            if (srcCRC == destCRC) compCRC = "(Same)"; else compCRC = "(Different)";


            string MsgText =
            String.Format("Overwrite {0}? \r\n" +
                          "Full path - {1} \r\n" +
                          "\r\n" +
                          "Original file - {2} \r\n" +
                          "Date - {3} \r\n" +
                          "CRC - {4} \r\n" +
                          "\r\n" +
                          "New file - {5} {6} \r\n" +
                          "Date - {7} {8} \r\n" +
                          "CRC - {9} {10} ",
                          new object[] 
			              {
			              	PathEx.GetFileName(destName), srcName,
			              	Helper.SizeInK((ulong)destSize), destTime, destCRC,
			              	Helper.SizeInK((ulong)srcSize), compSize,
			              	srcTime, compTime,
                            srcCRC, compCRC
			              });

            if (System.Windows.Forms.MessageBox.Show(MsgText, "Overwrite", System.Windows.Forms.MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                overwrite = true;

            return overwrite;
        }
        protected bool AskApplyToAll()
        {
            if (System.Windows.Forms.MessageBox.Show("Apply to All?", "Overwrite", System.Windows.Forms.MessageBoxButtons.YesNo) == System.Windows.Forms.DialogResult.Yes)
                return true;
            return false;
        }
        #endregion


        #endregion


        #region IWork Members

        public int ID { get; private set; }
        public string Title { get; protected set; }
        public DateTime ConstructTime { get; private set; }
        public DateTime StartTime { get; private set; }

        public WorkType WorkType { get; protected set; }
        public WorkStatusType WorkStatus { get; private set; }
        public WorkResultType WorkResult { get; private set; }

        public int Total { get; private set; }
        public int Completed { get; private set; }
        public int PercentCompleted { get { return (int)(Total == 0 ? 0 : (float)Completed / (float)Total * 100.0d); } }
        public string ProcessingItem { get; private set; }

        public bool Aborted { get { return _aborted; } }

        public string[] ProgressLog { get { return _progressLog.ToArray(); } }

        public event WorkProgressEventHandler WorkProgress;
        public event WorkStartEventHandler WorkStart;
        public event WorkFinishedEventHandler WorkFinished;
        public event WorkPausedEventHandler WorkPaused;

        public void Start(bool threaded)
        {
            StartTime = DateTime.Now;

            if (threaded)
            {
                _worker = new Thread(new ThreadStart(DoWork));
                _worker.Start();
            }
            else DoWork();
        }



        #endregion


        #region Data

        Thread _worker;
        bool _paused = false, _aborted = false;
        ManualResetEvent pauseTrigger = new ManualResetEvent(true);
        List<string> _progressLog = new List<string>();
        Action<WorkBase> _finishAction = null;
        #endregion

        #region IComparable Members

        public int CompareTo(object obj)
        {
            WorkBase compareWork = (WorkBase)obj;
            if (compareWork == null)
                return -1;
            return ConstructTime.CompareTo(compareWork.ConstructTime);
        }

        #endregion
    }
}
