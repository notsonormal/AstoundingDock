﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LYCJ (c) 2010 - http://www.quickzip.org/components                                                            //
// Release under LGPL license.                                                                                   //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

using System;
using System.Collections.Generic;
using System.Text;
using QuickZip.IO;

namespace System.IO.Tools
{
    public class MoveWork : ExWorkBase
    {
        public MoveWork(int id, FileSystemInfoEx[] src, DirectoryInfoEx dest)
            : base(id,
            src.Length > 0 ? src[0].Parent : null, dest)
        {
            _copyFrom = src;
            _dest = dest;
            WorkType = WorkType.Move;
        }

        void MoveFile(FileInfoEx item, DirectoryInfoEx destDir)
        {
            FileSystemInfoEx lookupItem = destDir[item.Name];

            bool overwrite = true;
            if (lookupItem != null)
                overwrite = AskOverwrite(item, lookupItem);

            if (overwrite)
            {
                if (lookupItem != null)
                    lookupItem.Delete();
                IOTools.Move(item.FullName, PathEx.Combine(destDir.FullName, item.Name));
            }
        }


        DirectoryInfoEx PrepateDirectoryForMove(DirectoryInfoEx srcDir, DirectoryInfoEx baseDir, string dirName)
        {
            bool isDirectory;
            if (!baseDir.Exists)
                baseDir.Create();
            if (baseDir.Contains(dirName, out isDirectory))
            {
                FileSystemInfoEx destSubItem = baseDir[dirName];

                bool overwrite = AskOverwrite(srcDir, destSubItem);
                if (!overwrite)
                    return null;
                else
                {
                    if (!isDirectory)
                    {
                        destSubItem.Delete();
                        return baseDir.CreateDirectory(dirName);
                    }
                    else return destSubItem as DirectoryInfoEx;
                }                
            }
            else return baseDir.CreateDirectory(dirName);
        }


        void MoveDirectory(DirectoryInfoEx srcDir, DirectoryInfoEx destDir)
        {
            FileInfoEx[] files = srcDir.GetFiles();
            AddTotalCount(files.Length);
            foreach (FileInfoEx fi in files)
                if (!Aborted)
                {
                    CheckPause();
                    AddCompletedCount(fi.FullName);
                    MoveFile(fi, destDir);
                }
            files = null;

            DirectoryInfoEx[] dirs = srcDir.GetDirectories();
            AddTotalCount(dirs.Length);
            foreach (DirectoryInfoEx di in dirs)
                if (!Aborted)
                {
                    CheckPause();
                    AddCompletedCount(di.FullName);
                    DirectoryInfoEx destSubDir = PrepateDirectoryForMove(di, destDir, di.Name);
                    if (destSubDir != null)
                        MoveDirectory(di, destSubDir);
                }
            dirs = null;

            if (srcDir.Exists && srcDir.GetFileSystemInfos().Length == 0)
                srcDir.Delete();
        }

        protected override void DoWork()
        {
            ReportWorkStart();
            CheckPause();

            AddTotalCount(_copyFrom.Length);
            foreach (FileSystemInfoEx item in _copyFrom)
                if (!Aborted)
                {
                    CheckPause();
                    AddCompletedCount(item.FullName);
                    if (item is FileInfoEx)
                        MoveFile(item as FileInfoEx, _dest);
                    else
                    {
                        DirectoryInfoEx dest = PrepateDirectoryForMove(item as DirectoryInfoEx, _dest, item.Name);
                        if (dest != null)
                            MoveDirectory(item as DirectoryInfoEx, dest);
                    }
                }
            ReportWorkCompleted();
        }


        #region Data

        FileSystemInfoEx[] _copyFrom;
        DirectoryInfoEx _dest;

        #endregion

    }
}
