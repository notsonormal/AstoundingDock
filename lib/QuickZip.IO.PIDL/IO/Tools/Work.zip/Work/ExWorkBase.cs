﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LYCJ (c) 2010 - http://www.quickzip.org/components                                                            //
// Release under LGPL license.                                                                                   //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;

namespace System.IO.Tools
{
    public abstract class ExWorkBase : WorkBase, IExWork
    {
        public ExWorkBase(int id, FileSystemInfoEx source, FileSystemInfoEx target)
            : base(id)
        {
            Source = source;
            Target = target;
        }

        public ExWorkBase(int id, FileSystemInfoEx source)
            : base(id)
        {
            Source = source;
        }

        #region IExWork Members

        public FileSystemInfoEx Source { get; private set; }

        public FileSystemInfoEx Target { get; private set; }

        public event WorkOverwriteEventHandler WorkOverwrite;
        public event WorkListEventHandler WorkList;

        #region Methods


        #region OverwriteTools

        protected bool AskOverwrite(FileSystemInfoEx srcEntry, FileSystemInfoEx destEntry)
        {
            if (_applyAll)
                return _overwrite;

            _overwrite = false;
            AskOverwrite(srcEntry, destEntry, ref _overwrite, ref _applyAll);
            return _overwrite;
        }

        protected void AskOverwrite(FileSystemInfoEx srcEntry, FileSystemInfoEx destEntry, ref bool overwrite, ref bool applyAll)
        {

            if (WorkOverwrite != null)
            {
                WorkOverwriteEventArgs e = new WorkOverwriteEventArgs(ID, srcEntry, destEntry, overwrite, applyAll);
                WorkOverwrite(this, e);
                overwrite = e.Overwrite;
                applyAll = e.ApplyToAll;
                return;
            }
            else
            {
                string destName = destEntry.Name;
                long destSize = (destEntry is FileInfoEx) ? (destEntry as FileInfoEx).Length : 0;
                DateTime destTime = destEntry.LastWriteTime;
                string destCRC = "";
                //if (!destEntry.IsFolder || srcEntry.IsArchiveRoot)
                //    destCRC = destEntry.CRC;

                string srcName = srcEntry.Name;
                long srcSize = (srcEntry is FileInfoEx) ? (srcEntry as FileInfoEx).Length : 0;
                DateTime srcTime = srcEntry.LastWriteTime;
                string srcCRC = "";
                //if (!srcEntry.IsFolder || srcEntry.IsArchiveRoot)
                //    srcCRC = srcEntry.CRC;

                overwrite = AskOverwriteDialog(srcName, srcSize, srcTime, srcCRC, destName, destSize, destTime, destCRC);
            }
        }
        #endregion


        #region ListTools

        protected bool ReportWorkList(FileSystemInfoEx itemList)
        {
            if (WorkList != null)
            {
                WorkListEventArgs args = new WorkListEventArgs(ID, itemList);
                WorkList(this, args);
                if (args.Cancel)
                    Abort();
                return !args.Cancel;
            }
            else return true;
        }

        #endregion

        #endregion

        #endregion

        #region Data

        bool _overwrite = false, _applyAll = false;

        #endregion
    }
}
