﻿///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// LYCJ (c) 2010 - http://www.quickzip.org/components                                                            //
// Release under LGPL license.                                                                                   //
//                                                                                                               //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;

namespace System.IO.Tools
{
    #region Events
    public class WorkAddedEventArgs : CancelEventArgs
    {
        public int ID { get; private set; }
        public IExWork Work { get; private set; }

        public WorkAddedEventArgs(int id, IExWork Work)
        {
            this.ID = id;
            this.Work = Work;
        }
    }

    public delegate void WorkAddedEventHandler(object sender, WorkAddedEventArgs e);
    #endregion

    public static class WorkSpawner
    {
        private static Dictionary<int, IExWork> onGoingWorkList = new Dictionary<int, IExWork>();
        private static Dictionary<int, IExWork> fullWorkList = new Dictionary<int, IExWork>();
        private static List<int> muteList = new List<int>();
        private static Random rand = new Random(0814);
        public static EventHandler MonitorWorkListUpdated;
        public static event WorkAddedEventHandler MonitorWorkListAdded;
        public static event WorkProgressEventHandler WorkProgress;
        public static event WorkStartEventHandler WorkStart;
        public static event WorkFinishedEventHandler WorkFinished;
        public static event WorkOverwriteEventHandler WorkOverwrite;
        public static event WorkListEventHandler WorkList;

        #region Spawn New Work
        private static int newKey()
        {
            int key = rand.Next();
            while (onGoingWorkList.ContainsKey(key))
                key = rand.Next();
            return key;
        }

        private static void hookWorkEvent(IExWork work)
        {
            work.WorkProgress += new WorkProgressEventHandler(OnWorkProgress);
            work.WorkStart += new WorkStartEventHandler(retVal_WorkStart);
            work.WorkFinished += new WorkFinishedEventHandler(retVal_WorkFinished);
            work.WorkList += new WorkListEventHandler(OnWorkList);
            work.WorkOverwrite += new WorkOverwriteEventHandler(OnWorkOverwrite);
        }

        private static int addWork(int key, IExWork Work)
        {            
            fullWorkList.Add(key, Work);
            if (MonitorWorkListAdded != null)
                MonitorWorkListAdded(null, new WorkAddedEventArgs(key, Work));
            return key;
        }

        #region SpawnWork
        public static int SpawnListWork(DirectoryInfoEx[] dirs, bool listDir, bool listFile, string fileMask)
        {
            lock (onGoingWorkList)
            {
                IExWork retVal = new ListWork(newKey(), dirs, listDir, listFile, fileMask);
                hookWorkEvent(retVal);
                return addWork(retVal.ID, retVal);
            }
        }


        public static int SpawnCopyWork(FileSystemInfoEx[] src, DirectoryInfoEx dest)
        {
            lock (onGoingWorkList)
            {
                IExWork retVal = new CopyWork(newKey(), src, dest);
                hookWorkEvent(retVal);
                return addWork(retVal.ID, retVal);
            }
        }

        public static int SpawnMoveWork(FileSystemInfoEx[] src, DirectoryInfoEx dest)
        {
            lock (onGoingWorkList)
            {
                IExWork retVal = new MoveWork(newKey(), src, dest);
                hookWorkEvent(retVal);
                return addWork(retVal.ID, retVal);
            }
        }

        public static int SpawnDeleteWork(FileSystemInfoEx[] items)
        {
            lock (onGoingWorkList)
            {
                IExWork retVal = new DeleteWork(newKey(), items);
                hookWorkEvent(retVal);
                return addWork(retVal.ID, retVal);
            }
        }
        #endregion



        #endregion

        #region Work Event

        static void ReportMonitorUpdated()
        {
            if (MonitorWorkListUpdated != null)
                MonitorWorkListUpdated(null, new EventArgs());
        }

        static void retVal_WorkStart(object sender, WorkStartEventArgs e)
        {
            if (!GetIsMuted((sender as IWork).ID))
                if (WorkStart != null)
                    WorkStart(sender, e);

            if (!onGoingWorkList.ContainsKey(e.ID) && fullWorkList.ContainsKey(e.ID))
                lock (onGoingWorkList)
                {
                    onGoingWorkList.Add(e.ID, fullWorkList[e.ID]);
                    ReportMonitorUpdated();
                }
        }

        static void OnWorkOverwrite(object sender, WorkOverwriteEventArgs e)
        {
            if (!GetIsMuted((sender as IWork).ID))
                if (WorkOverwrite != null)
                    WorkOverwrite(sender, e);
        }

        static void OnWorkList(object sender, WorkListEventArgs e)
        {
            if (!GetIsMuted((sender as IWork).ID))
                if (WorkList != null)
                    WorkList(sender, e);
        }

        static void retVal_WorkFinished(object sender, WorkFinishedEventArgs e)
        {
            if (!GetIsMuted((sender as IWork).ID))
                if (WorkFinished != null)
                    WorkFinished(sender, e);

            if (onGoingWorkList.ContainsKey(e.ID))
                lock (onGoingWorkList)
                {
                    onGoingWorkList.Remove(e.ID);
                    ReportMonitorUpdated();
                }
        }

        static void OnWorkProgress(object sender, WorkProgressEventArgs e)
        {
            if (!GetIsMuted((sender as IWork).ID))
                if (WorkProgress != null)
                    WorkProgress(sender, e);
        }
        #endregion

        #region Mute

        public static bool GetIsMuted(int key)
        {
            return muteList.Contains(key);
        }

        public static void SetIsMuted(int key, bool value)
        {
            lock(muteList)
            if (value)
            { if (!muteList.Contains(key)) muteList.Add(key); }
            else if (muteList.Contains(key)) muteList.Remove(key);

        }

        #endregion

        private static void startID(int[] workIDs, int currentIdx)
        {
            if (currentIdx < workIDs.Length - 1)
                Works[workIDs[currentIdx]].WorkFinished +=
                    delegate { startID(workIDs, currentIdx + 1); };
            Works[workIDs[currentIdx]].Start(true);
        }

        public static void Start(int[] workIDs)
        {
            startID(workIDs, 0);
        }

        public static void Start(int workID)
        {
            Works[workID].Start(true);
        }

        #region Public Properties

        public static Dictionary<int, IExWork> Works { get { return fullWorkList; } }
        #endregion
    }
}
